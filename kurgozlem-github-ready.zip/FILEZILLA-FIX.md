# 🔧 FILEZILLA BAĞLANTI SORUN ÇÖZÜMÜ

## ❌ HATALAR:
- Access denied (Kimlik doğrulama hatası)
- ETIMEDOUT Port 21 (FTP/SFTP karışıklığı)
- SSH bağlantı reddedildi

## ✅ ÇÖZÜM 1: AYARLARI KONTROL ET

### FileZilla Site Manager:
```
Host: 45.136.6.177
Port: 22
Protocol: SFTP (SSH File Transfer Protocol)
Logon Type: Normal
User: root
Password: [doğru şifreyi gir]
```

## ✅ ÇÖZÜM 2: ALTERNATIF KULLANICILAR

### Ubuntu kullanıcısını dene:
```
Host: 45.136.6.177
Port: 22
Protocol: SFTP
User: ubuntu
Password: [şifre]
```

### www-data kullanıcısı:
```
Host: 45.136.6.177
Port: 22
Protocol: SFTP
User: www-data
Password: [şifre]
```

## ✅ ÇÖZÜM 3: SSH ANAHTAR YÖNTEMİ

### Logon Type: Key file
- Private key dosyası (.pem) kullan
- Host Provider'dan anahtar dosyası al

## ✅ ÇÖZÜM 4: TERMINAL İLE UPLOAD

### SCP kullanarak:
```bash
# Local'den sunucuya kopyala
scp -r PRODUCTION-DOMAINS/vds.kurgozlem.com/* root@45.136.6.177:/var/www/vds.kurgozlem.com/
scp -r PRODUCTION-DOMAINS/vts.kurgozlem.com/* root@45.136.6.177:/var/www/vts.kurgozlem.com/
```

### RSYNC kullanarak:
```bash
rsync -avz -e ssh PRODUCTION-DOMAINS/vds.kurgozlem.com/ root@45.136.6.177:/var/www/vds.kurgozlem.com/
rsync -avz -e ssh PRODUCTION-DOMAINS/vts.kurgozlem.com/ root@45.136.6.177:/var/www/vts.kurgozlem.com/
```

## ✅ ÇÖZÜM 5: WEB HOSTING PANEL

### cPanel/Plesk varsa:
- File Manager kullan
- Web hosting paneline giriş yap
- /var/www/ klasörüne dosyaları yükle

## 🔍 TESTİ
```bash
# SSH bağlantısını test et
ssh root@45.136.6.177

# Farklı kullanıcı dene
ssh ubuntu@45.136.6.177
``` 