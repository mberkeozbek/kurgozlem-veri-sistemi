# 🌐 DOMAIN BAZINDA DEPLOYMENT - KURGÖZLEM

## 📁 HAZIR KLASÖR YAPISI

### Domain Klasörleri:
```
PRODUCTION-DOMAINS/
├── vds.kurgozlem.com/     ← VDS dosyaları (280KB)
│   ├── server.js, config.js, package.json, .env
│   └── routes/, middleware/, services/, utils/, data/, views/
├── vts.kurgozlem.com/     ← VTS dosyaları (48KB)
│   ├── index.js, config.js, package.json, .env
│   └── services/, utils/
└── FILEZILLA-GUIDE.md     ← Transfer kılavuzu
```

## 🚀 FILEZILLA TRANSFER PLANI

### 📡 Bağlantı Bilgileri:
- **Host:** 45.136.6.177
- **Port:** 22 (SFTP)
- **Username:** root
- **Protocol:** SFTP

### 🔄 Transfer İşlemleri:
1. **VDS:** `vds.kurgozlem.com/` → `/var/www/vds.kurgozlem.com/`
2. **VTS:** `vts.kurgozlem.com/` → `/var/www/vts.kurgozlem.com/`

### ⚙️ Sunucuda Çalıştırılacak:
```bash
cd /var/www/vds.kurgozlem.com && npm install --production
cd /var/www/vts.kurgozlem.com && npm install --production
pm2 start /var/www/vds.kurgozlem.com/server.js --name "vds"
pm2 start /var/www/vts.kurgozlem.com/index.js --name "vts"
```

## ✅ HAZIR DURUM
- Temiz dosyalar: ✅
- Domain yapısı: ✅  
- .env dosyaları: ✅
- Transfer kılavuzu: ✅ 