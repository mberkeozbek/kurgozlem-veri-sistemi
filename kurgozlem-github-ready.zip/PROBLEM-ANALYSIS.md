# 🚨 KRİTİK SORUN ANALİZİ - KURGÖZLEM

## ❌ MEVCUT DURUM
- **PM2 Status:** VDS + VTS "online" görünüyor
- **Port Test:** 3001 + 3002 CONNECTION_TIMED_OUT
- **Domain Test:** 502 Bad Gateway
- **IP Test:** ERR_CONNECTION_TIMED_OUT

## 🔍 ROOT CAUSE ANALİZİ

### 1️⃣ MUHTEMEL SEBEPLER:

#### A) REDIS BAĞLANTI HATASI
- .env'de REDIS_PASSWORD yanlış
- Redis service çalışmıyor
- VDS Redis'e bağlanamıyor = crash

#### B) PORT BİNDİNG HATASI  
- HOST=0.0.0.0 yerine localhost olabilir
- PORT değişkenleri yanlış
- Permission denied (port binding)

#### C) FİREWALL BLOCKAJLARI
- UFW 3001/3002 port'ları kapalı
- iptables rules
- Cloud provider firewall

#### D) .ENV KONFİGÜRASYON HATALARI
- NODE_ENV=production config hataları
- CORS ALLOWED_ORIGINS boş array
- API KEY authentication crash

## 🛠️ TEST PLANI

### PHASE 1: PM2 GERÇEK DURUM
```bash
pm2 logs vds --lines 50     # Error mesajları
pm2 logs vts --lines 50     # Crash nedenleri  
pm2 restart all             # Fresh restart
```

### PHASE 2: PORT VE NETWORK
```bash
ss -tulpn | grep :300       # Port dinleme kontrolü
ufw status                  # Firewall durumu
systemctl status redis      # Redis service
```

### PHASE 3: KONFİGÜRASYON KONTROL
```bash
cat /var/www/vds.kurgozlem.com/.env
cat /var/www/vts.kurgozlem.com/.env
redis-cli ping              # Redis connectivity
```

### PHASE 4: MANUAL START TEST
```bash
cd /var/www/vds.kurgozlem.com
node server.js             # Manuel başlatma, error'ları gör
```

## 🎯 ÖNCELIK SIRASI
1. **HIGH:** PM2 logs (crash nedeni)  
2. **HIGH:** Redis service status
3. **MEDIUM:** Firewall/UFW kontrol
4. **MEDIUM:** .env konfigürasyon
5. **LOW:** Nginx proxy settings

## ⚠️ TAHMIN
- %80 Redis bağlantı hatası
- %15 Port binding permission  
- %5 Firewall blocking 