# 🚀 FILEZILLA DEPLOYMENT KÕLAVUZU

## 📡 SUNUCU BAĞLANTI BİLGİLERİ
```
Host: 45.136.6.177
Port: 22 (SFTP)
Protocol: SFTP
Username: root
Password: [Sunucu şifresi]
```

## 📁 HEDEF KLASÖR YAPISI
```
/var/www/
├── vds.kurgozlem.com/
│   └── [VDS dosyaları buraya]
└── vts.kurgozlem.com/
    └── [VTS dosyaları buraya]
```

## 🔄 TRANSFER ADIMI

### 1️⃣ FileZilla'da Bağlantı:
- File → Site Manager
- New Site: "KurGözlem Server"
- Host: `45.136.6.177`
- Port: `22`
- Protocol: `SFTP`
- Username: `root`
- Password: [şifre gir]

### 2️⃣ Transfer İşlemleri:
1. **Sol panel (local):** Bu klasörü aç
   - `PRODUCTION-DOMAINS/vds.kurgozlem.com/`

2. **Sağ panel (server):** Bu klasöre git
   - `/var/www/vds.kurgozlem.com/`

3. **VDS transfer:** Tüm dosyaları sürükle-bırak

4. **VTS için tekrarla:**
   - Local: `PRODUCTION-DOMAINS/vts.kurgozlem.com/`
   - Server: `/var/www/vts.kurgozlem.com/`

## ⚙️ TRANSFER SONRASI KOMUTLAR
```bash
# SSH ile sunucuya bağlan ve şu komutları çalıştır:

# VDS kurulum
cd /var/www/vds.kurgozlem.com
npm install --production
pm2 start server.js --name "vds"

# VTS kurulum  
cd /var/www/vts.kurgozlem.com
npm install --production
pm2 start index.js --name "vts"

# Kontrol
pm2 status
pm2 logs
```

## 🔒 DOSYA İZİNLERİ
```bash
# İzinleri düzelt
chown -R www-data:www-data /var/www/vds.kurgozlem.com
chown -R www-data:www-data /var/www/vts.kurgozlem.com
chmod -R 755 /var/www/
``` 