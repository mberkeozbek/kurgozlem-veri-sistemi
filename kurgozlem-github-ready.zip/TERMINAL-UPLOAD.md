# 🚀 TERMINAL İLE PRODUCTION UPLOAD

## ✅ NEDEN TERMINAL?
- **FileZilla sorunları:** SFTP protokol karışıklığı
- **Terminal avantajları:** Tek komutla tüm transfer
- **SSH çalışıyor:** Password prompt geldi = bağlantı var

## 📦 UPLOAD KOMUTU

### 1️⃣ VDS Upload:
```bash
scp -r PRODUCTION-DOMAINS/vds.kurgozlem.com/* root@45.136.6.177:/var/www/vds.kurgozlem.com/
```

### 2️⃣ VTS Upload:
```bash
scp -r PRODUCTION-DOMAINS/vts.kurgozlem.com/* root@45.136.6.177:/var/www/vts.kurgozlem.com/
```

## 🔄 ALTERNATIVE: RSYNC (Daha İyi)
```bash
# Sync ile eksik dosyaları otomatik tamamlar
rsync -avz --progress PRODUCTION-DOMAINS/vds.kurgozlem.com/ root@45.136.6.177:/var/www/vds.kurgozlem.com/

rsync -avz --progress PRODUCTION-DOMAINS/vts.kurgozlem.com/ root@45.136.6.177:/var/www/vts.kurgozlem.com/
```

## 📋 FULL DEPLOYMENT SCRIPT

### Tek komutla her şey:
```bash
# 1. Sunucuda klasörleri oluştur
ssh root@45.136.6.177 "mkdir -p /var/www/vds.kurgozlem.com /var/www/vts.kurgozlem.com"

# 2. Dosyaları transfer et
rsync -avz --progress PRODUCTION-DOMAINS/vds.kurgozlem.com/ root@45.136.6.177:/var/www/vds.kurgozlem.com/
rsync -avz --progress PRODUCTION-DOMAINS/vts.kurgozlem.com/ root@45.136.6.177:/var/www/vts.kurgozlem.com/

# 3. Sunucuda kurulum
ssh root@45.136.6.177 "
cd /var/www/vds.kurgozlem.com && npm install --production
cd /var/www/vts.kurgozlem.com && npm install --production
pm2 start /var/www/vds.kurgozlem.com/server.js --name vds
pm2 start /var/www/vts.kurgozlem.com/index.js --name vts
pm2 status
"
```

## 🏗️ AVANTAJLAR
- ✅ Tek seferde tüm işlem
- ✅ Progress gösterir (--progress)
- ✅ Kesintide kaldığı yerden devam
- ✅ İzin sorunları yok  
- ✅ Otomatik klasör oluşturma

## ⚠️ ŞİFRE
- Her komutta şifre soracak
- SSH key kullanırsan şifre sormaz
- Ya da şifre manager kullan 